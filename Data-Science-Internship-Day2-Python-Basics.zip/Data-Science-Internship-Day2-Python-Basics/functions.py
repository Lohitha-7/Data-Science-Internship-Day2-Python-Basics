def greet(name):
    print("Hello,",name)

greet("Lohitha")

def square(num):
    return num*num

print("Square:",square(5))
