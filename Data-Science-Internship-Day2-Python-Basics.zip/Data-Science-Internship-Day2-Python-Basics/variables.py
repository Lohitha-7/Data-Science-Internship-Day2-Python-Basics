name="Lohitha"
age=20
cgpa=8.7
print("Name:",name)
print("Age:",age)
print("CGPA:",cgpa)
