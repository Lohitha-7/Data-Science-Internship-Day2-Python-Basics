# Day 2 – Python Basics

Includes Python basics programs.
Author: Ketha Lohitha
